# StablerCharacter
 StablerCharacter is a Game engine which is mainly used for creating Advance Text Adventure game

StablerCharacter will bring the New Exprerience of playing a Text adventure game.

## Plan
StablerCharacter is planned to have a Complete Rendering engine by the end of 2021.

StablerCharacter is based on [Arcade](https://arcade.academy/) library. (2D) and soon will be based on [Ursina engine](https://www.ursinaengine.org/) as well. (3D)
