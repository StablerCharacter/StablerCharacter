from arcade import color, csscolor
import StablerCharacterArcade as scr

scr.setGameName("Test Game")
scr.setGameViewBackgroundColor(csscolor.CORNFLOWER_BLUE)
scr.start() # Setup the window
scr.showDefaultMainMenuView()