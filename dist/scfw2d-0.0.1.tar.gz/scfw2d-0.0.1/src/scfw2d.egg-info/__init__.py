__all__ = (
	"__version__",
	"__email__",
	"__license__",
	"__copyright__",
)

__copyright__ = "Copyright 2021 Satakun Utama and Individual contributors"
__version__ = "0.0.1"
__author__ = "lines-of-codes"
__email__ = "admin@susite.ga"
__license__ = "MIT License"